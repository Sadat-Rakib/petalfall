import type { Point } from "./tree";
import type { Wind } from "./wind";
export interface PetalWorld {
    w: number;
    h: number;
    groundY: number;
    u: number;
    scale: number;
    sources: Point[];
    colors: string[];
    faded: string;
}
export declare class Petals {
    private readonly world;
    private readonly wind;
    target: number;
    /** Weather: rain weighs petals down so they fall faster. */
    fallMul: number;
    private items;
    private debt;
    constructor(world: PetalWorld, wind: Wind);
    scatter(): void;
    update(dt: number): void;
    /** Wind from a point: pushes nearby petals away and lets them tumble up. */
    impulse(x: number, y: number, radius: number, strength: number): void;
    /** Shake blossom loose from the crown near a point. */
    shed(x: number, y: number, radius: number, count: number): void;
    draw(ctx: CanvasRenderingContext2D): void;
    private make;
    private drop;
}
