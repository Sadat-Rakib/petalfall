import type { Grid } from "./grid";
import type { Wind } from "./wind";
export interface SwayOptions {
    /** "hang": strands fixed at the top, free at the bottom. "mass": a body that sways as one. "grow": blades fixed at the bottom, free at the top (grass). */
    mode: "hang" | "mass" | "grow";
    /** Swing in cells: how far a hanging strand's tip can move, or how hard a poke shoves a mass. */
    swing: number;
    /** Random ripples per second while the wind blows; 0 for none. They pop up at random spots on the layer. */
    ambient?: number;
    /** Speed of ripples: 1 is normal, less is slower and more drawn out. */
    tempo?: number;
    /** How far a ripple reaches sideways, in px (it fades off about 3.5x farther vertically). */
    radius?: number;
}
export declare class SwayLayer {
    private scratch;
    private scratchCtx;
    private ready;
    private buildId;
    private bitmap;
    private mask;
    private cols;
    private anchor;
    private runBottom;
    private runHeight;
    private rowHas;
    private x0;
    private x1;
    private y0;
    private y1;
    private cw;
    private ch;
    private dpr;
    private mode;
    private swing;
    private ambient;
    private tempo;
    private nextAmbient;
    private reach;
    private offsets;
    private pokes;
    private now;
    private radius;
    build(grid: Grid, cw: number, ch: number, dpr: number, opts: SwayOptions): void;
    /** Release the bitmap; the layer draws nothing afterwards until it is built again. */
    dispose(): void;
    /** Is this screen point on this layer? */
    hit(x: number, y: number): boolean;
    /** Strike the layer at a point: a ripple spreads out from it and dies away. `radius` is its reach in px. */
    poke(x: number, y: number, amp?: number, radius?: number): void;
    draw(ctx: CanvasRenderingContext2D, t: number, wind: Wind): void;
    private stir;
    private pokeShift;
}
