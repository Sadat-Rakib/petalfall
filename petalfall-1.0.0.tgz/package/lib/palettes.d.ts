import { type Rgb } from "./color";
declare const ANCHORS: {
    sakura: [string, string, string];
    blush: [string, string, string];
    rose: [string, string, string];
    peach: [string, string, string];
    coral: [string, string, string];
    gold: [string, string, string];
    lavender: [string, string, string];
    violet: [string, string, string];
    sky: [string, string, string];
    mint: [string, string, string];
    matcha: [string, string, string];
    white: [string, string, string];
    pine: [string, string, string];
    juniper: [string, string, string];
    maple: [string, string, string];
    autumn: [string, string, string];
};
export type PaletteName = keyof typeof ANCHORS;
export declare const PALETTE_NAMES: PaletteName[];
/** Eight tones, 0 lightest to 7 deepest. */
export declare function makeRamp(name: string): Rgb[];
export {};
