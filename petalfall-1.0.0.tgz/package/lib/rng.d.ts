export type Rng = () => number;
export declare function mulberry32(seed: number): Rng;
