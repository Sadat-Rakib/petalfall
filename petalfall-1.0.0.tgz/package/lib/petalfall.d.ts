import { type BonsaiForm } from "./bonsai";
import { PALETTE_NAMES, type PaletteName } from "./palettes";
import { WEATHERS, type Weather } from "./weather";
export declare const TREES: readonly ["sakura", "bonsai"];
export type TreeOption = (typeof TREES)[number];
/** The kinds of cherry. */
export declare const FORMS: readonly ["yoshino", "bush", "shidare", "random"];
/** The styles of bonsai. */
export declare const BONSAI_FORMS: readonly [...BonsaiForm[], "random"];
export type FormOption = (typeof FORMS)[number] | (typeof BONSAI_FORMS)[number];
export { PALETTE_NAMES as PALETTES, WEATHERS };
export type { PaletteName, Weather };
/** The forms that go with each tree. */
export declare const FORMS_OF: Readonly<Record<TreeOption, readonly string[]>>;
/** What a tree starts with: its first form, and leaf or blossom colours to suit it. */
export declare const TREE_DEFAULTS: Readonly<Record<TreeOption, {
    form: FormOption;
    palette: PaletteName;
}>>;
/** Everything you can set. Every field is optional; what you leave out keeps its default. */
export interface PetalfallOptions {
    /** Which tree: `"sakura"` (a cherry in blossom) or `"bonsai"` (a tree growing from a mossy rock). Default `"sakura"`. */
    tree?: TreeOption;
    /** Blossom or leaf colour. Default `"sakura"` for the cherry, `"pine"` for the bonsai. See `PALETTES`. */
    palette?: PaletteName;
    /**
     * The cherry: `"yoshino"` (spreading), `"bush"` (a full cloud), `"shidare"` (weeping) or `"random"`.
     * The bonsai: `"moyogi"` (S-curved), `"chokkan"` (straight), `"shakan"` (slanting), `"fukinagashi"` (windswept), `"sokan"` (twin trunk),
     * `"hokidachi"` (broom), `"ishitsuki"` (on a stone), `"nejikan"` (spiral trunk), `"hankengai"` (semi-cascade), `"kengai"` (cascade), `"bunjin"` (tall and thin) or `"random"`.
     * Default: the first of the tree's own list. A form that does not belong to the tree is ignored.
     */
    form?: FormOption;
    /** `true` draws a finely branched pixel tree, `false` the blocky cell style. The bonsai is always drawn finely. Default `false`. */
    detail?: boolean;
    /** How many petals, 1 to 10. Default 5 (2 for people who prefer reduced motion). */
    petals?: number;
    /** Wind strength 0 to 10, or `false` for dead still air. Default 3. */
    wind?: number | false;
    /** The sky: `"clear"`, `"sunset"`, `"moonlight"`, `"overcast"` or `"mist"`. Default `"clear"`. */
    weather?: Weather;
    /** Rain falling through the weather. Default `false`. */
    rain?: boolean;
    /** `"sky"` draws its own night sky; `"transparent"` draws only the tree, petals and rain over your page. Default `"sky"`. */
    background?: "sky" | "transparent";
    /** Draw at most this many frames per second, 5 to 60. Default 60. */
    fps?: number;
    /** The same seed grows the same tree. Default: a random one. */
    seed?: number;
    /** Wind and rain sound, plus a chime on click. Browsers only allow it after a click or key press. Default `false`. */
    sound?: boolean;
    /** Clicking or dragging on the scene shakes the blossom. Default `true`. Turn it off to let clicks through. */
    interactive?: boolean;
    /** Use the arrowhead cursor in the blossom colour over the scene. Default `true`. */
    cursor?: boolean;
}
/** Options that only matter when the scene is created. */
export interface PetalfallCreateOptions extends PetalfallOptions {
    /** Fill the whole window (position: fixed) instead of the container. Default: true when the container is `document.body`. */
    fixed?: boolean;
    /** `z-index` of the canvas. Default: -1 when fixed, otherwise unset. */
    zIndex?: number;
    /** CSS `touch-action` of the canvas. Default `"pan-y"`, so a finger can still scroll the page. */
    touchAction?: string;
    /** Calm the wind and use fewer petals for people who ask their system for reduced motion. Default `true`. */
    respectReducedMotion?: boolean;
}
/** The options as the scene is using them right now. */
export type ResolvedOptions = Required<PetalfallOptions>;
export declare const DEFAULTS: Readonly<ResolvedOptions>;
/**
 * A growing tree (a cherry in blossom, or a bonsai) drawn on a canvas inside `container`.
 * Create one with {@link createPetalfall}.
 */
export declare class Petalfall {
    /** The canvas the scene is drawn on. */
    readonly canvas: HTMLCanvasElement;
    /** The element it lives in. */
    readonly container: HTMLElement;
    private opts;
    private readonly ctx;
    private readonly treeCanvas;
    private readonly treeCtx;
    private readonly bgCanvas;
    private readonly bgCtx;
    private readonly wind;
    private readonly audio;
    private readonly world;
    private readonly petals;
    private readonly weatherFx;
    private readonly rain;
    private readonly leaves;
    private readonly curtain;
    private readonly grassLayer;
    private ramp;
    private cellW;
    private cellH;
    private w;
    private h;
    private readonly fixed;
    private restoreContainerPosition;
    private raf;
    private paused;
    private visible;
    private destroyed;
    private lastFrame;
    private pending;
    private frames;
    private fpsSince;
    private measuredFps;
    private pointer;
    private lastBrush;
    private lastLeafBrush;
    private resizeTimer;
    private readonly resizeObserver;
    private readonly visibilityObserver;
    constructor(container: HTMLElement | string, options?: PetalfallCreateOptions);
    /** The options as the scene is using them now (a copy). */
    get options(): Readonly<ResolvedOptions>;
    /** The frame rate being drawn right now, measured twice a second. */
    get fps(): number;
    /**
     * Change any options. Changing `form` grows a new tree (unless you also pass a `seed`), and
     * changing `detail` redraws the tree in the other style; everything else updates in place.
     */
    set(options: PetalfallOptions): this;
    /** Grow a new tree. Pass a seed to get the same tree again. */
    regrow(seed?: number): this;
    /** Send a gust through the tree. `strength` is the peak wind in pixels per second (default 140). Does nothing while the wind is off. */
    gust(strength?: number): this;
    /** Stop drawing until `resume()` is called. */
    pause(): this;
    resume(): this;
    /** The current picture as an image. */
    screenshot(type?: string, quality?: number): Promise<Blob>;
    /** Stop everything and remove the canvas. The instance cannot be used afterwards. */
    destroy(): void;
    private sync;
    private applyWind;
    private applyInteractive;
    private setPetalCount;
    /** Drawn in single pixels: the cherry in detail mode, and always the bonsai. */
    private get fine();
    private measure;
    private readonly onResize;
    private paintBackdrop;
    /** Grow a tree on the current grid and bake it into the offscreen canvas. */
    private grow;
    private layout;
    private readonly frame;
    private local;
    private readonly onPointerDown;
    private readonly onPointerMove;
    private readonly endDrag;
}
/** Grow a cherry blossom tree inside `container` (an element or a CSS selector). */
export declare function createPetalfall(container: HTMLElement | string, options?: PetalfallCreateOptions): Petalfall;
