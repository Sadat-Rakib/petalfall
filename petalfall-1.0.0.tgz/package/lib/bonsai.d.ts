import { type Rgb } from "./color";
import { type Grid } from "./grid";
import type { Rng } from "./rng";
import type { Point } from "./tree";
export type BonsaiForm = "moyogi" | "chokkan" | "shakan" | "fukinagashi" | "sokan" | "hokidachi" | "ishitsuki" | "nejikan" | "hankengai" | "kengai" | "bunjin";
export declare const BONSAI_STYLES: readonly BonsaiForm[];
export interface BonsaiEnv {
    grid: Grid;
    foliage: Grid;
    grass: Grid;
    ramp: Rgb[];
    rng: Rng;
}
export interface BonsaiResult {
    sources: Point[];
    groundRow: number;
}
/** `wild` is for the Random option: the trunk's whole path is invented afresh, with its own bends, coils and twist. */
export declare function growBonsai(env: BonsaiEnv, form: BonsaiForm, wild?: boolean): BonsaiResult;
