export type Rgb = [number, number, number];
export declare function hex(h: string): Rgb;
/** t = 0 gives a, t = 1 gives b. */
export declare function mix(a: Rgb, b: Rgb, t: number): Rgb;
export declare function brighten(c: Rgb, k?: number): Rgb;
export declare function css(c: Rgb): string;
