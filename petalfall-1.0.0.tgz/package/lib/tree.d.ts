import { type Rgb } from "./color";
import { type Grid } from "./grid";
import type { Rng } from "./rng";
export type Form = "yoshino" | "bush" | "shidare";
export type Point = [number, number];
export declare const WOOD_D: Rgb;
export declare const WOOD_M: Rgb;
export declare const WOOD_L: Rgb;
export declare const GRASS: Rgb;
export declare const GRASS_DARK: Rgb;
export interface CellEnv {
    grid: Grid;
    ramp: Rgb[];
    rowBg: Rgb[];
    rowHaze: Rgb[];
    aspect: number;
    rng: Rng;
    foliage: Grid;
    strands: Grid;
}
/** Grow a tree out of character-style cells. Returns the cells petals fall from. */
export declare function growCellTree(env: CellEnv, form: Form): Point[];
