import type { Rgb } from "./color";
export declare const WEATHERS: readonly ["clear", "sunset", "moonlight", "overcast", "mist"];
export type Weather = (typeof WEATHERS)[number];
type Rgba = [number, number, number, number];
export interface Look {
    tint: Rgb;
    veilTop: Rgba;
    veilBottom: Rgba;
    glow: Rgb;
    glowAlpha: number;
    glowX: number;
    glowY: number;
    vignette: number;
    cloud: number;
    fog: number;
    rain: number;
    windMul: number;
    fall: number;
    dark: number;
}
export declare const LOOKS: Record<Weather, Look>;
/** The look for a weather, with rain falling through it when `rain` is on. */
export declare function lookFor(weather: Weather, rain: boolean): Look;
export declare class WeatherFx {
    readonly look: Look;
    private target;
    private readonly cloudSprite;
    private readonly fogSprite;
    private readonly clouds;
    private readonly fogs;
    set(weather: Weather, rain: boolean): void;
    /** Ease every number of the current look toward the target. */
    update(dt: number): void;
    /** Sky colour, light, clouds and fog, laid over the finished scene. */
    drawGrade(ctx: CanvasRenderingContext2D, w: number, h: number, t: number): void;
    drawVignette(ctx: CanvasRenderingContext2D, w: number, h: number): void;
    private drift;
}
export {};
