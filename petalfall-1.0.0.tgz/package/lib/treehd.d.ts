import { type Rgb } from "./color";
import { type Grid } from "./grid";
import type { Rng } from "./rng";
import { type Form, type Point } from "./tree";
export interface HdEnv {
    grid: Grid;
    foliage: Grid;
    strands: Grid;
    ramp: Rgb[];
    bgBottom: Rgb;
    rng: Rng;
}
/**
 * A fully branched tree in single pixels. Branches come from space colonisation:
 * the crown is filled with attraction points and the tree grows toward them a
 * node at a time, each point dropped once a branch reaches it. Branches
 * competing for those points is what gives the heavy limbs that fork and taper
 * into fine twigs.
 */
export declare function growDetailTree(env: HdEnv, form: Form): Point[];
