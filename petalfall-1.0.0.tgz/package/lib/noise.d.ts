export declare function noise2(x: number, y: number): number;
