import { type Petalfall } from "./petalfall";
export declare class PetalfallElement extends HTMLElement {
    static observedAttributes: ("background" | "cursor" | "detail" | "form" | "fps" | "interactive" | "palette" | "petals" | "rain" | "seed" | "sound" | "tree" | "weather" | "wind")[];
    private petalfall;
    /** The running scene, for methods such as `gust()` and `regrow()`. */
    get instance(): Petalfall | null;
    connectedCallback(): void;
    disconnectedCallback(): void;
    attributeChangedCallback(): void;
    private flag;
    private number;
    private read;
}
