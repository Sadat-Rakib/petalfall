import type { Wind } from "./wind";
export declare class Rain {
    private drops;
    private splashes;
    update(dt: number, intensity: number, w: number, groundY: number, scale: number, wind: Wind): void;
    draw(ctx: CanvasRenderingContext2D, wind: Wind, intensity: number): void;
    clear(): void;
    private make;
}
