import { type Grid } from "./grid";
/**
 * Paint the whole grid once; the tree never changes between frames.
 *
 * The grid is painted onto a transparent canvas and the sky changes behind it,
 * so a cell on the outline cannot be pre-blended with a fixed background colour:
 * it would leave a dark box round it against a different sky. Blossom, strand and
 * grass cells that touch open space fade into whatever is behind them instead.
 * Cells inside the mass, and all wood, keep their solid shaded colour.
 */
export declare function drawGrid(ctx: CanvasRenderingContext2D, grid: Grid, cw: number, ch: number): void;
