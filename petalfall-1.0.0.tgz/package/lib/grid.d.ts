import type { Rgb } from "./color";
export declare const K_NONE = 0;
export declare const K_WOOD = 1;
export declare const K_CANOPY = 2;
export declare const K_GROUND = 3;
/** Glyph -1 is a solid block blended toward the background by `cov`. */
export declare const G_BLOCK = -1;
export declare const G_DOT = 4;
export declare const G_TUFT = 5;
export declare const G_BLADE = 6;
export declare const G_LINE = 7;
export interface Cell {
    color: Rgb;
    bg: Rgb;
    cov: number;
    glyph: number;
    kind: number;
    /** The cell's background is just the sky: draw nothing behind it, and fade partial cells into what is there. */
    sky?: boolean;
}
export declare class Grid {
    readonly w: number;
    readonly h: number;
    readonly cells: (Cell | null)[];
    constructor(w: number, h: number);
    set(x: number, y: number, cell: Cell): void;
    at(x: number, y: number): Cell | null;
    kind(x: number, y: number): number;
}
