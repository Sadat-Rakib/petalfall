export declare class Audio {
    private ctx;
    private filter;
    private gain;
    private rainGain;
    private level;
    enabled: boolean;
    toggle(): boolean;
    /** Switch the sound on or off. Browsers only let it start after a click or key press. */
    set(on: boolean): boolean;
    /** Try again to start the audio engine after a user gesture, if sound was asked for earlier. */
    resume(): void;
    /** Stop everything and release the audio engine. */
    destroy(): void;
    setWind(strength: number): void;
    /** Rain sound, 0..1: a hiss of filtered noise that follows the weather. */
    setRain(level: number): void;
    /** A soft wind-chime note, played when the tree is touched. */
    chime(): void;
    private ramp;
    private start;
}
