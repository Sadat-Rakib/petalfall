import { type Rgb } from "./color";
export declare function cursorFor(ramp: Rgb[]): string;
