export declare class Wind {
    /** 0..10, the knob the interface exposes. */
    level: number;
    /** Weather multiplies the wind: storms blow harder, mist is still. */
    boost: number;
    /** Master switch: when off the air is dead still. */
    enabled: boolean;
    /** Scales everything down for reduced-motion users. */
    calm: number;
    /** Current horizontal speed. */
    x: number;
    /** 0..1 overall effort, used for the wind sound. */
    strength: number;
    private t;
    private gust;
    private gustAge;
    private gustDuration;
    private gustPeak;
    private nextGust;
    update(dt: number): void;
    /** Start a gust now; `peak` is in px/s. */
    trigger(peak?: number): void;
}
